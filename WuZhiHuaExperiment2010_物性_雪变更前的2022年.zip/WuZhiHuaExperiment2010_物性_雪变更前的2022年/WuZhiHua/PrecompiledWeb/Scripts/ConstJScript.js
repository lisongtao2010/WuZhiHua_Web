﻿var conLightGreen;
var conLightBlue;
var conLightRed;
var conSelectRowClolor;
var conLightYellow;

conLightGreen = "#93FF93";  //扫描Text 被选中颜色
conLightYellow = "#FFFF99"  //扫描Text颜色
conLightBlue = "#84C1FF";
conLightRed = "#FF2D2D";
conSelectRowClolor = "#FFE4B5";


var GL_OLD_SELECTED_ROW;
